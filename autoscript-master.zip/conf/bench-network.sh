wget freevps.us/downloads/bench.sh -O - -o /dev/null|bash
